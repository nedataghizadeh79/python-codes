adad=int(input())
counter=0
javab=0
aval_ast=True
for i in range(1,adad+1):
    if adad%i==0:
        counter+=1
        # counter=counter+1

    if counter<=2:
        aval_ast=True

    else:
        aval_ast=False

if aval_ast:
    print("adade ", i, " aval ast♥")
else:
    print("adade ", i, " aval nist☻")
