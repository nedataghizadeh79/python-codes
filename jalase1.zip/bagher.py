one=0
two=0
three=0
four=0
five=0
ll=[]

yek=input()
if yek.__contains__("HAFEZ") or yek.__contains__("MOLANA"):
    one=1
    ll.append(yek)


do=input()
if do.__contains__("HAFEZ") or do.__contains__("MOLANA"):
    two=2
    ll.append(do)

se=input()
if se.__contains__("HAFEZ") or se.__contains__("MOLANA"):
    three=3
    ll.append(se)

chahar=input()
if chahar.__contains__("HAFEZ") or chahar.__contains__("MOLANA"):
    four=4
    ll.append(chahar)

panj=input()
if panj.__contains__("HAFEZ") or panj.__contains__("MOLANA"):
    five=5
    ll.append(panj)


if one==0 and two==0 and three==0 and four==0 and five==0:
    print("NOT FOUND!")

else:
    for i in ll:
        print(i,end=" ")


# hala hmin soal ra pas az yadgiri tabee (def) saaee konid bezanid
# هدف از این سوال این بود که با تابع کانتین و کار با لیست اشنا بشوید و کارایی و استفاده توابع نیز برای شما روشن تر شود
# چنانچه همین سوال را با تعریف تابع بزنید بسیاری از کد های اضافه و تکراری حذف شده و کد حالت بهینه را به خود میگیرد