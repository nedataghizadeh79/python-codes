yek=0
do=0
se=0
chahar=0
panj=0
ll=[]

one=input()
if one.__contains__("HAFEZ") or one.__contains__("MOLANA"):
    yek=1
    ll.append(yek)


do=input()
if do.__contains__("HAFEZ") or do.__contains__("MOLANA"):
    do=2
    ll.append(do)

se=input()
if se.__contains__("HAFEZ") or se.__contains__("MOLANA"):
    se=3
    ll.append(se)

chahar=input()
if chahar.__contains__("HAFEZ") or chahar.__contains__("MOLANA"):
    chahar=4
    ll.append(chahar)

panj=input()
if panj.__contains__("HAFEZ") or panj.__contains__("MOLANA"):
    panj=5
    ll.append(panj)


if yek==0 and do==0 and se==0 and chahar==0 and panj==0:
    print("NOT FOUND!")

else:
    for i in ll:
        print(i,end=" ")


# hala hmin soal ra pas az yadgiri tabee (def) saaee konid bezanid
# هدف از این سوال این بود که با تابع کانتین و کار با لیست اشنا بشوید و کارایی و استفاده توابع نیز برای شما روشن تر شود
# چنانچه همین سوال را با تعریف تابع بزنید بسیاری از کد های اضافه و تکراری حذف شده و کد حالت بهینه را به خود میگیرد