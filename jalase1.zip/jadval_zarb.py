adad=int(input())
for i in range(1,adad+1):
    print(i,end=" ")
    for j in range(2,adad+1):
        print(j*i,end=" ")
    print("")
    # در خط بالا میتوانستید از n\  هم برای زدن اینتر استفاده نمایید